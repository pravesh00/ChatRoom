package com.five5.activityplanner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {
    Button addBtn;
    RecyclerView rec;
    activity_adapter mAdapter;
    ArrayList<activity> act = new ArrayList<>();
    Gson gson;
    GsonBuilder g= new GsonBuilder();





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addBtn=(Button)findViewById(R.id.btnAdd);
        mAdapter= new activity_adapter(act,getApplicationContext());
        rec=(RecyclerView)findViewById(R.id.recycler);
        rec.setAdapter(mAdapter);
        rec.setLayoutManager(new LinearLayoutManager(this));
        act.add(new activity("6 hrs","Complete Tutorial 1"));


        final AlertDialog.Builder builder= new AlertDialog.Builder(this);
        final View dialog=LayoutInflater.from(this).inflate(R.layout.add_dialog,null);
        Button close=(Button) dialog.findViewById(R.id.btnClose);
        final EditText txtnew =(EditText)dialog.findViewById(R.id.txtAct);

        final JSONObject activityJson = new JSONObject();
        for (int i=0;i<act.size();i++){
            try {
                activityJson.put("Name",act.get(i).getName());
                activityJson.put("Date",act.get(i).getDate());


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        gson=g.create();
        activity curr = gson.fromJson(activityJson.toString(),activity.class);
        act.add(curr);





        builder.setView(dialog);
        builder.setNegativeButton("", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                finish();
            }
        });

       builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialogInterface, int i) {
               Date date = new Date();
               act.add(new activity(date.toString().substring(11,16),txtnew.getText().toString()));

               mAdapter.notifyDataSetChanged();

           }
       });
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final AlertDialog a= builder.create();
                a.show();

            }
        });
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(rec);
        rec.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade));


    }
    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            int position = viewHolder.getAdapterPosition();
            switch(direction){
                case ItemTouchHelper.LEFT :
                    act.remove(position);
                    mAdapter.notifyDataSetChanged();
                    Toast.makeText(getApplicationContext(),"Activity Deleted",Toast.LENGTH_SHORT).show();
                    break;
                case ItemTouchHelper.RIGHT:;
                    act.remove(position);
                    mAdapter.notifyDataSetChanged();
                    Toast.makeText(getApplicationContext(),"Activity Completed",Toast.LENGTH_SHORT).show();
                break;
            }

        }

        @Override
        public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            c.drawText("hye",0,1,new Paint());


            if(dX >0)
            {c.clipRect(0f, viewHolder.itemView.getTop(),
                        dX,viewHolder.itemView.getBottom());
                c.drawColor(Color.parseColor("#7FCF72"));}
            else
            {
                c.clipRect(-dX, viewHolder.itemView.getTop(),
                        0,viewHolder.itemView.getBottom());
                c.drawColor(Color.parseColor("#F37077"));}

        }
    };

}