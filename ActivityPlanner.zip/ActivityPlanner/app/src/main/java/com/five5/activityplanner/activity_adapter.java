package com.five5.activityplanner;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class activity_adapter extends RecyclerView.Adapter<activity_adapter.ViewHolder> {
    ArrayList<activity> activities;
    Context mContext;

    public activity_adapter(ArrayList<activity> activities, Context mContext) {
        this.activities = activities;
        this.mContext = mContext;
    }

    public activity_adapter(ArrayList<activity> activities) {
        this.activities = activities;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View li=LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_layout,null);
        return new ViewHolder(li);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        activity currAct=activities.get(position);
        holder.r.setAnimation(AnimationUtils.loadAnimation(mContext,R.anim.fade));
        holder.timeLeft.setText(currAct.getDate());
        holder.txtName.setText(currAct.getName());

    }

    @Override
    public int getItemCount() {
        return activities.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView timeLeft , txtName;
        RelativeLayout r;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName=(TextView)itemView.findViewById(R.id.txtActName);
            timeLeft=(TextView)itemView.findViewById(R.id.txtTimeLeft);
            r=(RelativeLayout)itemView.findViewById(R.id.rela);

        }
    }
}
